function start(){
	var favoriteSites = ["youtube", "reddit", "google", "nick", "chiuhuha spin"];
	println(favoriteSites[0]);
	favoriteSites[0] = "codehs.com";
	println(favoriteSites[0]);
}
