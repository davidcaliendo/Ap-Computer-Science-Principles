var NUM_CIRCLES = 15;
var MIN_RADIUS = 10;
var MAX_RADIUS = 40;
var DELAY = 500;

var circles = [];

function start(){
	createCircles();
	setTimer(goCrazy, DELAY);
}

function createCircles(){
	for(var i = 0; i < NUM_CIRCLES; i++){
		var circle = new Circle(MIN_RADIUS);
		updateCircle(circle);
		add(circle);
		circles.push(circle);
	}
}

function goCrazy(){
	for(var i = 0; i < circles.length; i++){
		updateCircle(circles[i]);
	}
}

function updateCircle(circle){
	var x = Randomizer.nextInt(
		MIN_RADIUS, getWidth() - MIN_RADIUS);
	var y = Randomizer.nextInt(
		MIN_RADIUS, getHeight() - MIN_RADIUS);
	circle.setPosition(x, y);
	circle.setColor(Color.BLUE);
}
