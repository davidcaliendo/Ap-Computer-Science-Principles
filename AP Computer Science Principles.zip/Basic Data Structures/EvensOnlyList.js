function start(){
	var arr = [1, 2, 3 ,4 ,5 ,6];
	var doubled = [];
	
	
	var evens = onlyEvens(arr);
	println(evens);
}

function onlyEvens(arr){
      for(var i = 0; i < arr.length; i++){
        if(arr[i] % 2 === 0){
            
        }else{
            println(i);
        }
        
    }


}
