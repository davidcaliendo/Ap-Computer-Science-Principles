function start(){
    var array = [];
    array.push("A");
    array.push("B");
    array.push("C");
    array.push("D");
    array.push("E");
    array.push("F");
    
    println(array[0]);
    println(array[1]);
    println(array[2]);
    println(array[3]);
    println(array[4]);
    println(array[5]);
   
    var last = array.pop();
    var secondLast = array.pop();
  
    println(array[0]);
    println(array[1]);
    println(array[2]);
    println(array[3]);
    println(array[4]);
    println(array[5]);
}
