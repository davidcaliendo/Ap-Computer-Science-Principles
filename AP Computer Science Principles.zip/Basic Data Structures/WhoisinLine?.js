function start(){
	var line = ["Sam", "Lisa", "Laurie", "Bob", "Ryan"];
	var line2 = ["Tony", "Lisa", "Laurie", "Karen"];
	
	var idx = indexOf(line, "Bob");
	println("Bob is in the first line.");
	
	var ipp = indexOf(line2, "Bob");
	println(ipp);
}

function indexOf(arr, str){
	for(var i = 0; i < arr.length; i++){
		var cur = arr[i];
		if(cur == str){
			return i;
		}
	}
	return "Bob is not in the second line.";
}
