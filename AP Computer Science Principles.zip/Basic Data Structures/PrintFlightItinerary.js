function start(){
	var flightList = ["San Francisco", "New York", "Chicago", "Honolulu"];
	print(flightList);
}
