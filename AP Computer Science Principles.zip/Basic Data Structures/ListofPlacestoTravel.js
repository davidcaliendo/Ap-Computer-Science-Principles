function start(){
    var travelList = ["England", "Australia", "Ecuador", "China", "Germany"];
    print(travelList[2]);
}
