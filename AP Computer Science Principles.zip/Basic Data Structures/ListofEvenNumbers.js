function start(){
	var numList = ["0", "2", "4", "6", "8"];
	println(numList[0]);
	println(numList[2]);
	println(numList[4]);
}
