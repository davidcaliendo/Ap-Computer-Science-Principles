function start(){
	var arr = [10, 20, 30, 40];
	
	
	var answer = doubleList(arr);
	println(answer);
}

function doubleList(arr){
    for(var i = 0; i < arr.length; i++){
		 var dub = arr[i];
         var dubb = dub*2;
         arr.push(dubb);
		
	}
	
}
