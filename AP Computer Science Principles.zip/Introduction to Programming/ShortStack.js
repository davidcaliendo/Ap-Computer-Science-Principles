move();
putBall();
putBall();
move();
