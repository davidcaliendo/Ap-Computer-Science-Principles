for(var i = 0; i < 6; i++){
	putBall();
}

move();
