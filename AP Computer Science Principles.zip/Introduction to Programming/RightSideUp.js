function start(){
	if (facingSouth()) {
	    turnLeft();
	} else {
	    turnAround();
	}
}
