function start(){
	move();
	buildTower();
	move();
	move();
	buildTower();
	turnLeft();
	move();
	move();
	move();
	turnRight();
}

function buildTower() {
    turnLeft();
    putBall();
    move();
    putBall();
    move();
    putBall();
    halfFlip();
    move();
    move();
    turnLeft();
}

function turnRight() {
    turnLeft();
    turnLeft();
    turnLeft();
} 

function halfFlip(){
    turnLeft();
    turnLeft();
}
