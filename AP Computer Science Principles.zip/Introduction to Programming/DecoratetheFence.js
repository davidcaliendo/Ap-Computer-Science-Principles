function start(){
    while(frontIsClear()) {
        move();
    }
    if(frontIsBlocked()){
        turnLeft();
    }
    while(rightIsBlocked()){
        putBall();
        move();
        while(rightIsClear()){
            move();
    }
        }
    
}
