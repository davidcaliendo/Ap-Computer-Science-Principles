function makePancakes(){
    putBall();
    putBall();
    putBall();
}

move();
makePancakes();
move();
move();
makePancakes();
move();
move();
makePancakes();
move();

