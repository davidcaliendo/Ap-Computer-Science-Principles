function start(){
	while(frontIsClear()) {
	    putBall();
	    move();
	}
	putBall();
}
