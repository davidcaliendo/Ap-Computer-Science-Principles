function backflip() { 
    turnLeft();
    turnLeft();
    turnLeft();
    turnLeft();
}

move();
move();
backflip();
move();
move();
backflip();
    
