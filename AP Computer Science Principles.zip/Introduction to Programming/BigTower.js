/* This program draws a big tower from Karel's starting spot */
function start(){
	while (notFacingNorth()) {
	    turnLeft();
	}
	
	while (frontIsClear()) {
	    putBall();
	    move();
	}
	
	putBall();
}


function code() {
    turnLeft();
    turnLeft();
    turnLeft();
}

function moreCode() {
    turnLeft();
    turnLeft();
}
