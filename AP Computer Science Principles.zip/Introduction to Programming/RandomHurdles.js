function start(){
	while (frontIsClear()) {
	    move();
	    if (frontIsBlocked()) {
	        jumpHurdle();
	    }
	}
}

function jumpHurdle() {
    turnLeft();
    move();
    turnRight();
    move();
    turnRight();
    move();
    turnLeft();
}
