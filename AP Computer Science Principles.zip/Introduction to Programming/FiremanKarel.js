turnRight();
moveThree();
turnLeft();



function moveThree(){
    move();
    move();
    move();
}
function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}
