function start(){
	move();
	buildTower();
	move();
	move();
	buildTower();
	turnLeft();
	move();
	move();
	move();
	turnRight();
}

// This function build the tower that Karel will need to climb

function buildTower() {
    turnLeft();
    putBall();
    move();
    putBall();
    move();
    putBall();
    halfFlip();
    move();
    move();
    turnLeft();
}

// This function gets Karel to turn left three times making him turn right

function turnRight() {
    turnLeft();
    turnLeft();
    turnLeft();
} 

// This function makes Karel turn 180 degrees

function halfFlip(){
    turnLeft();
    turnLeft();
}
