move();
turnAround();

function turnAround(){
	turnLeft();
	turnLeft();
}
