/* This program prints out "Hello, world." */
function start(){
	println("Hello world.");
}
