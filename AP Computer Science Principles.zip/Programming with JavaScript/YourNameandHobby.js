/* This program should print out your 
 * name, and a hobby you have */
function start(){
println("My name is David Caliendo");
println("I like codehs :)");


}

// Sample output:
//
// My name is Jeremy
// I like to juggle
//
