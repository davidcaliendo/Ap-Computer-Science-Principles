function start(){
	var numApples = 20;
}
