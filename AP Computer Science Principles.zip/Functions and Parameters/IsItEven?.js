var SENTINEL = 0;

function start(){
	while (true){
	    var int = readInt("Enter a number: ");
	    if(int == 0){
	        println("Done!");
	        break;
	    }
	    else{
	        isEven(int);
	    }
	}
}

function isEven(x){
    if (x % 2 == 0){
        println("Even");
    }
    else{
        println("Odd");
    }
}
