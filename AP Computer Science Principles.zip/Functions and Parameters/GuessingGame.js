var MIN = 0;
var MAX = 100;

/* This program will play a simple guessing game.
 * The user will guess, and the computer should print if
 * the guess was too high, too low, or correct.
 */
function start(){
    println("This program plays the guessing game.");
    println("Pick a number between " + MIN + " and " + MAX);

    var numberToGuess = Randomizer.nextInt(MIN, MAX);
    while (true){
        var guess = readInt("What is your guess? ");

        if (guess == numberToGuess){
            break;
        }

        if (guess > numberToGuess){
            println("Your guess was too high.");
        }else{
            println("Your guess was too low.");
        }
    }
	
    println("Correct!");
}
