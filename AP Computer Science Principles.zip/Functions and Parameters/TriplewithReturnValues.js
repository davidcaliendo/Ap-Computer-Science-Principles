function start(){
	var x = triple(4);
}

function triple(x){
    var tripled = x * 3;
    println(tripled);
}
