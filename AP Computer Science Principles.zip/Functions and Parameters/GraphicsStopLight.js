var LIGHT_RADIUS = 35;
var STOPLIGHT_WIDTH = 120;
var STOPLIGHT_HEIGHT = 350;
var BUFFER = 100;
var GRAY_COLOR = "#737071";
var x = getWidth() / 2;
var y = getHeight() / 2;

function start(){
	rectangle();
	drawCircleYellow();
	drawCircleRed();
	drawCircleGreen();
}

function rectangle(){
    var rect = new Rectangle(STOPLIGHT_WIDTH, STOPLIGHT_HEIGHT);
    rect.setPosition(x - 60, y - 175);
    rect.setColor("#737071");
    add(rect);
}

function drawCircleYellow(){
    var yellow_circle = new Circle(LIGHT_RADIUS);
    yellow_circle.setPosition(x, y);
    yellow_circle.setColor(Color.yellow);
    add(yellow_circle);
}

function drawCircleRed(){
    var red_circle = new Circle(LIGHT_RADIUS);
    red_circle.setPosition(x, y - 100);
    red_circle.setColor(Color.red);
    add(red_circle);
}

function drawCircleGreen(){
    var green_circle = new Circle(LIGHT_RADIUS);
    green_circle.setPosition(x, y + 100);
    green_circle.setColor(Color.green);
    add(green_circle);
}
