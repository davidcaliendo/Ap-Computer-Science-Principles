function start(){
	var x = square(10);
}

function square(x){
    var squared = x * x;
    println(squared);
}
