function start(){
    triangleArea(2, 4);
}

function triangleArea(base, height){
    var area = (1/2) * base * height;
    println(area);
}
