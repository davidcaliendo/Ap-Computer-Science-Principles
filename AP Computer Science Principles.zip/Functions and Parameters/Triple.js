function start(){
	triple(5);
}

function triple(x){
    var tripled =  x + x + x;
    println(tripled);
}
