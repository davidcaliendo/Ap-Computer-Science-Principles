function start() {
    var circle = new Circle(50);
    circle.setPosition(250,300);
    circle.setColor(Color.red);
    add(circle);
    
    var rect = new Rectangle(100,50);
    rect.setPosition(60, 150);
    rect.setColor(Color.green);
    add(rect);
    
    var line = new Line(50, -50, 300, -300);
    line.setPosition(100,75);
    line.setColor(Color.blue);
    add(line);
}
