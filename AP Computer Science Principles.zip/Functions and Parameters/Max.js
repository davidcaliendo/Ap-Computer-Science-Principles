function start(){
	var int1 = readInt("Enter an integer: ");
	var int2 = readInt("Enter another integer: ");
	var num = max(int1, int2);
}

function max(x, y){
    if (x > y){
        println(x + " is greater than " + y);
        return x;
    }
    else if(x == y){
        println("They are equal");
        return x;
    }
    else{
        println(y + " is greater than " + x);
        return y;
    }
}
