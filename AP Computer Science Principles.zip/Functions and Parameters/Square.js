function start(){
	square(4);
}

function square(x){
    var squared = x * x;
    println(squared);
}
