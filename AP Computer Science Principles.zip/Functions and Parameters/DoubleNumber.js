function start(){
	doubleNumber(5);
	
	doubleNumber(12);
	
	var y = 3;
	doubleNumber(y);
}

function doubleNumber(x){
	var doubleX = 2 * x;
	println(doubleX);
}
